# MyDAW
Scaffold with MIDI scheduler integrated.
