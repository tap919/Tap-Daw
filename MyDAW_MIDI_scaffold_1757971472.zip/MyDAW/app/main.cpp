#include <iostream>
int main(){
  std::cout<<"MyDAW scaffold\n";
  return 0;
}
